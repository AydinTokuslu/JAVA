package _04_switchCase;

import java.util.Scanner;

public class Soru_Bankamatik {
	/*
	 * Bakıye öğrenme para çekme yatırma ve çıkış işlemlerinin olduğu bir bankamatik pr kodlayınız
	 */

    public static void main(String[] args) {

      

    }
}

