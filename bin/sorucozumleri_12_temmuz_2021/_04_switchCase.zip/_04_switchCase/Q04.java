package _04_switchCase;

public class Q04 {
    public static void main(String[] args) {

        // Bugüne (pazartesi) göre 100 gün sonra hangi gün olduğunuz yazdırınız.
        

        
    }
}

